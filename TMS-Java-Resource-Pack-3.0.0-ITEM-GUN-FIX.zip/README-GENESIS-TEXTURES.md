# TMS Phone Resource Pack 1.9.0

This pack keeps every asset from TMS Java Resource Pack 1.7.0, replaces the
twenty Phone icons with the completed 1.8.0 set, and adds the Genesis 1.9.0
visual language.

New Phone models:

- expedition
- research
- blueprints
- manufacturing
- facilities
- genesis_core
- events
- materials
- nexus_engineer
- genesis_loop

New item models:

- rift_alloy
- memory_lattice
- rift_biofiber
- prime_core_fragment
- genesis_blueprint
- rift_field_kit

All new textures are 128×128 RGBA PNG files with transparent backgrounds and
remain distinguishable when rendered at 32×32.


## 2.2.0 GG Dragon texture update

- `gatling_gun_doragon` replaced with the approved TMS silver-dragon design.
- Java uses a 12-frame 256px glow animation; Bedrock uses the matching 256px static texture.
- No item ID, serial, ownership, damage, ammo, or sound behavior was changed.
